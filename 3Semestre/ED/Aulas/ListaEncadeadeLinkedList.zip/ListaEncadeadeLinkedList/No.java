// Essa classe não vai mais ser necessaria;
// public class No<Tipo> {
//     private Tipo elemento;
//     private No proximo;

//     // Um só com a informação mas sem ponteiro
//     public No(Tipo elemento) {
//         this.elemento = elemento;
//         this.proximo = null;
//     };

//     // E o outro com a informação e o ponteiro
//     public No(Tipo elemento, No proximo) {
//         this.elemento = elemento;
//         this.proximo = proximo;
//     }

//     @Override
//     public String toString() {
//         return "No [elemento=" + elemento + ", proximo=" + proximo + "]";
//     }

// };
