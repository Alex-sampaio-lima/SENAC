package br.senac.tads.dsw.dados_pessoais;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DadosPessoaisApplicationTests {

	@Test
	void contextLoads() {
	}

}
