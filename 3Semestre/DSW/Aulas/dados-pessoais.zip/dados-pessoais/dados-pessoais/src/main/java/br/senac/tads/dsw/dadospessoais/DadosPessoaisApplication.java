package br.senac.tads.dsw.dadospessoais;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DadosPessoaisApplication {

	public static void main(String[] args) {
		SpringApplication.run(DadosPessoaisApplication.class, args);
	}

}
