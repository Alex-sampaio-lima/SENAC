# simple-web-server
Servidor Web simples desenvolvido com Java SE

A aplicação retorna a mensagem de requisição enviada

Serve para analisar os cabeçalhos e os dados enviados.
