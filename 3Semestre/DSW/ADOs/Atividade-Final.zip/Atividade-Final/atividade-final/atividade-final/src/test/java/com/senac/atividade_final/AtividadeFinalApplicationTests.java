package com.senac.atividade_final;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtividadeFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
