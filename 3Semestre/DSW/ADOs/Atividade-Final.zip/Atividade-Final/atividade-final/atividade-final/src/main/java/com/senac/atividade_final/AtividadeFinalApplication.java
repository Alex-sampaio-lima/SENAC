package com.senac.atividade_final;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtividadeFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtividadeFinalApplication.class, args);
	}

}
